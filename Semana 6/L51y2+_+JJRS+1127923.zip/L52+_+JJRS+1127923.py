print("Ejercicio 2")

dia= input("Ingrese el numero del dia ")
xdia = int(dia) 

if xdia == 1:
    print("Lunes")

if xdia == 2:
    print("Martes")

if xdia == 3:
    print("Miercoles")

if xdia == 4:
    print("Jueves")

if xdia == 5:
    print("Viernes")

if xdia == 6:
    print("Sabado")

if xdia == 7:
    print("Domingo")

if xdia > 7:
    print("Error, el numero a ingresar debe de estar contenido entre 1 y 7")