print("Ejercicio 1")

Num = input("Ingrese numero un numero entero")
xnumero = int(Num)
if xnumero > 0:
    print("El numero es positivo")
else:
    print("El numero es negativo")

if xnumero == 0:
    print("El numero es igual a cero")